<?php
/**
 * @copyright Copyright 2003-2022 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: DrByte 2020 Jul 10 Modified in v1.5.8-alpha $
 */
/**
 * Security Patch v138 20090619
 */ 

/////// NOTE: THIS FILE NO LONGER RELEVANT in v1.3.9 and higher.  PLEASE DELETE FROM YOUR SERVER.