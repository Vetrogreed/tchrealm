<?php
/**
 * @copyright Copyright 2003-2020 Zen Cart Development Team
 * @author inspired from sales_report_graphs.php,v 0.01 2002/11/27 19:02:22 cwi Exp  Released under the GNU General Public License $
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson 2020 Apr 11 Modified in v1.5.7 $
 */

// adjust and uncomment if a different value is desired
//define('SALES_REPORT_GRAPHS_FILTER_DEFAULT', '00000000110000000000');

