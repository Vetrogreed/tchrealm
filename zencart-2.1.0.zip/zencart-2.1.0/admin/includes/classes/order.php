<?php
// @deprecated since v1.5.6
// Any code relying on this file existing should be refactored to 
// load the class from the non-admin includes directory:
include DIR_FS_CATALOG . DIR_WS_CLASSES . 'order.php';
