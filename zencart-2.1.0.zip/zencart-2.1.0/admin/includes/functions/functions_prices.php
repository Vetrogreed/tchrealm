<?php

// This file is no longer used since ZC v1.5.8
// Please remove it from your site
